_use_minified = True


def set_use_minified(value):
    global _use_minified
    _use_minified = value


def get_use_minified():
    return _use_minified